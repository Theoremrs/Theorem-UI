# @rustyreddb/browser

The canonical RustyRed database in a web page. A dedicated worker holds the
graph as a `.RR` file in the origin private file system (OPFS). This is the
same file format, store and Cypher engine as the native database, built from
`rustyred-thg-browser` in the Theorem repository.

```js
import { open } from '@rustyreddb/browser'

const db = await open('records', { controlEvents: false, shared: true })
await db.mutate({
  upsertNodes: [{ id: 'org:a', labels: ['Org'], properties: { name: 'Alder' } }],
})
const orgs = await db.queryNodes({ label: 'Org' })
const stop = db.subscribe({ method: 'queryNodes', args: { label: 'Org' } }, console.log)
```

- `open(name, settings)` opens the database in OPFS directory `name`, creating
  it when absent. One worker holds a file at a time. With `shared: true`,
  every page of the origin opening `name` the same way uses one database
  through whichever page holds it.
- `inMemory(settings)` is an empty graph with no file.
- `remove(name)` deletes a closed database's directory.
- `controlEvents: false` stops writes to labelled nodes from also committing
  `ControlEvent` nodes. Use it when nothing reads the control plane.

Every call resolves after its commit is durable. `query` only reads: a
write is refused with `cypher_write_unsupported`, and `mutate` changes
records. Mutations refuse records other owners keep (`owner_record`). Integers
arrive as JavaScript numbers, which are exact up to 2^53. Past versions of
records stay in the file as its history.

The page needs a secure context with OPFS synchronous access handles. Give
`worker` a function that makes `new Worker(new URL('@rustyreddb/browser/worker',
import.meta.url), { type: 'module' })` (or your own module that imports it),
and `wasm` the URL of `@rustyreddb/browser/rustyred.wasm` when your bundler
moves it.

Third-party notices for the bundled engine are in `licenses/`.

Build the tarball from the repository root with `build.sh`.
