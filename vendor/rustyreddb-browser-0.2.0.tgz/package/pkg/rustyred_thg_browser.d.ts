/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

export type ReadableStreamType = "bytes";

export type BrowserDatabaseMode = "create" | "open" | "read_only";
export type CypherParameter = null | boolean | string | bigint | number
| CypherParameter[] | { [name: string]: CypherParameter };
export type CypherParameters = { [name: string]: CypherParameter };
export type BrowserValue = null | boolean | string | bigint | number
| BrowserValue[] | { [name: string]: BrowserValue };
export type BrowserTaggedScalar =
| { t: "null" }
| { t: "bool"; v: boolean }
| { t: "int"; v: bigint }
| { t: "float"; v: number | "NaN" | "Infinity" | "-Infinity" }
| { t: "string" | "uuid" | "date" | "time" | "localtime" | "datetime" | "localdatetime" | "duration"; v: string }
| { t: "point"; v: { srid: bigint; x: number; y: number; z?: number | null } };
export type BrowserVectorCoordinate = "INTEGER8" | "INTEGER16" | "INTEGER32" | "INTEGER"
| "FLOAT16" | "BFLOAT16" | "FLOAT32" | "FLOAT";
export interface BrowserTaggedVector {
    t: "vector";
    coord: BrowserVectorCoordinate;
    v: Extract<BrowserTaggedScalar, { t: "int" | "float" }>[];
}
export interface BrowserTaggedBytes { t: "bytes"; v: bigint[]; }
export type BrowserTaggedParameter = BrowserTaggedScalar
| { t: "list"; v: BrowserTaggedParameter[] }
| { t: "map"; v: { [name: string]: BrowserTaggedParameter } }
| BrowserTaggedVector
| BrowserTaggedBytes;
export type BrowserTaggedParameters = { [name: string]: BrowserTaggedParameter };
export interface BrowserTaggedNode {
    id: string;
    labels: string[];
    properties: { [name: string]: BrowserTaggedValue };
    virtual?: true;
}
export interface BrowserTaggedRelationship {
    id: string;
    type: string;
    from: string;
    to: string;
    properties: { [name: string]: BrowserTaggedValue };
    virtual?: true;
}
export type BrowserTaggedValue = BrowserTaggedScalar
| { t: "list"; v: BrowserTaggedValue[] }
| { t: "map"; v: { [name: string]: BrowserTaggedValue } }
| BrowserTaggedVector
| BrowserTaggedBytes
| { t: "node"; v: BrowserTaggedNode }
| { t: "relationship"; v: BrowserTaggedRelationship }
| { t: "path"; v: { nodes: BrowserTaggedNode[]; relationships: BrowserTaggedRelationship[] } };
export interface BrowserGraphPosition {
    txnId: bigint;
    root: string;
}
export interface BrowserDatabaseStatus extends BrowserGraphPosition {
    databaseId: string;
    state: "ready" | "read_only" | "recovery_failure";
    access: "writer" | "read_only";
    failureCode: string | null;
    formatVersion: bigint;
    capabilityVersion: bigint;
    generation: bigint;
}
export interface BrowserQueryResult<V = BrowserValue> extends BrowserGraphPosition {
    columns: string[];
    rows: V[][];
    profile: BrowserClauseMetrics[];
}
export interface BrowserCommitResult<V = BrowserValue> {
    columns: string[];
    rows: V[][];
    profile: (BrowserClauseMetrics | BrowserBatchMetrics)[];
    outcome: BrowserGraphPosition & ({ state: "unchanged" }
    | { state: "committed"; requestToken: string });
    batchTransactions: BrowserGraphPosition[];
}
export interface BrowserClauseMetrics {
    stage: bigint;
    part: bigint;
    clause: bigint;
    rows: bigint;
    memory_bytes: bigint;
    expression_built_bytes: bigint;
    time_ns: bigint;
    kernel: string | null;
    batched: boolean;
}
export interface BrowserBatchMetrics {
    clause: "CALL IN TRANSACTIONS";
    peak_concurrent_batches: bigint;
    used_native_threads: boolean;
    retries: bigint;
    accepted_transactions: bigint;
}
export interface BrowserQueryPlan {
    engine: "relate";
    parts: string[][];
    columns: string[];
    parameters: string[];
    effects: { kind: string; nested: boolean; detail: string | null }[];
}
export interface BrowserDatabaseError extends Error {
    code: string;
    requestToken?: string;
    transactions?: BrowserGraphPosition[];
    cause?: BrowserDatabaseError;
    diagnostic?: {
        stage: string;
        neo4jCode: string;
        gqlStatus: string;
        tckClass: string | null;
        tckDetail: string | null;
    };
}
export type BrowserDocumentOrigin =
| { kind: "user_authored"; actorId: string; originSurface: string }
| { kind: "agent_encoded"; sourceMemoryDocId: string; actorId: string; originSurface: string;
derivationRef: string; contentAddress: string; sourceReadOnly: boolean; promotedDocumentId?: string };
export interface BrowserFilesEntry {
    entryId: string;
    path: string;
    kind: "file" | "directory";
    size: bigint;
    mtimeMs: bigint;
    contentHash?: string;
    backing: "agentfs" | "document" | "plan";
    readOnly: boolean;
    placed: boolean;
    document?: {
        documentId: string;
        documentKind: string;
        origin: BrowserDocumentOrigin;
        revision: { position: bigint; contentDigest: string };
        collectionIds: string[];
    };
    plan?: { planId: string; status: string; digest: string };
}
export interface BrowserFilesEntries {
    schema: "theorem-files/1";
    entries: BrowserFilesEntry[];
    position: bigint;
}
export interface BrowserFilesContent {
    schema: "theorem-files/1";
    entry: BrowserFilesEntry;
    encoding: "utf8" | "base64";
    data: string;
    contentHash: string;
}
export interface BrowserFilesWriteReceipt {
    schema: "theorem-files/1";
    entry: BrowserFilesEntry;
    contentHash: string;
    merged: boolean;
}
export interface BrowserFilesMoveReceipt {
    schema: "theorem-files/1";
    entry: BrowserFilesEntry;
    rewritten: string[];
}
export interface BrowserFilesRemoveReceipt {
    schema: "theorem-files/1";
    path: string;
    archived: boolean;
}
export interface BrowserFilesLinks {
    schema: "theorem-files/1";
    links: {
        from: string;
        target: string;
        resolved?: string;
        kind: "wikilink" | "markdown" | "embed" | "related";
        heading?: string;
        block?: string;
        line: bigint;
        receiptId?: string;
    }[];
}
export type BrowserCommand =
| { op: "entries" }
| { op: "content"; path: string }
| { op: "write"; key: string; path: string; data: string; encoding?: "utf8" | "base64"; ifMatch?: string; createOnly?: boolean }
| { op: "move"; key: string; from: string; to: string }
| { op: "remove"; key: string; path: string }
| { op: "links" | "backlinks"; path: string }
| { op: "reresolveLinks" }
| { op: "commit"; statement: string; parameters?: CypherParameters; requestToken?: string; tagged?: false }
| { op: "commit"; statement: string; parameters?: BrowserTaggedParameters; requestToken?: string; tagged: true };
export type BrowserCommandResult<C extends BrowserCommand = BrowserCommand> =
C extends { op: "entries" } ? BrowserFilesEntries :
C extends { op: "content" } ? BrowserFilesContent :
C extends { op: "write" } ? BrowserFilesWriteReceipt :
C extends { op: "move" } ? BrowserFilesMoveReceipt :
C extends { op: "remove" } ? BrowserFilesRemoveReceipt :
C extends { op: "links" | "backlinks" } ? BrowserFilesLinks :
C extends { op: "reresolveLinks" } ? bigint :
C extends { op: "commit"; tagged: true } ? BrowserCommitResult<BrowserTaggedValue> :
BrowserCommitResult;
export interface BrowserDatabase {
    query(statement: string, parameters?: CypherParameters | null, tagged?: false): BrowserQueryResult;
    query(statement: string, parameters: BrowserTaggedParameters | null, tagged: true): BrowserQueryResult<BrowserTaggedValue>;
    queryEvidence(statement: string, parameters?: CypherParameters | null, tagged?: false): BrowserQueryResult;
    queryEvidence(statement: string, parameters: BrowserTaggedParameters | null, tagged: true): BrowserQueryResult<BrowserTaggedValue>;
    queryAt(txnId: bigint, statement: string, parameters?: CypherParameters | null, tagged?: false, validAtMs?: bigint): BrowserQueryResult;
    queryAt(txnId: bigint, statement: string, parameters: BrowserTaggedParameters | null, tagged: true, validAtMs?: bigint): BrowserQueryResult<BrowserTaggedValue>;
    queryValidAt(epochMs: bigint, statement: string, parameters?: CypherParameters | null, tagged?: false): BrowserQueryResult;
    queryValidAt(epochMs: bigint, statement: string, parameters: BrowserTaggedParameters | null, tagged: true): BrowserQueryResult<BrowserTaggedValue>;
    command<C extends BrowserCommand>(request: C): BrowserCommandResult<C>;
    command(request: string): BrowserCommandResult;
}
export interface BrowserCompaction {
    generation: bigint;
    chunksRemoved: bigint;
    bytesRemoved: bigint;
    /** Past versions cut because they were older than the `historyDays` window. */
    commitsRemoved: bigint;
}



export class BrowserDatabase {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Rebuild into the inactive slot and select it only after verification
     * and synchronization. The now-inactive old .RR is retained until the
     * next successfully started compaction.
     */
    compact(): Promise<BrowserCompaction>;
    explain(statement: string): BrowserQueryPlan;
    exportSnapshot(): Uint8Array;
    static importSnapshot(directory: string, filename: string, bytes: Uint8Array): Promise<BrowserDatabase>;
    /**
     * An empty database with no file, gone when the handle is freed. Its
     * journal grows in memory with every commit.
     */
    static inMemory(options?: string | null): BrowserDatabase;
    static open(directory: string, filename: string, mode: BrowserDatabaseMode, options?: string | null): Promise<BrowserDatabase>;
    /**
     * Answer one record call (`inspect`, `mutate`, `getNode`, `getEdge`,
     * `queryNodes`, `neighbors`, `query`). Arguments and result are JSON text.
     */
    recordCall(method: string, args: string): string;
    /**
     * Replace this handle's CSV grants with explicitly selected bytes.
     * Names match LOAD CSV sources exactly; no network or filesystem lookup
     * occurs. Empty input revokes all grants. Grants are never exported or
     * retained across reopen, and do not permit writes on a read-only handle.
     */
    setCsvSources(sources: Record<string, Uint8Array>): void;
    status(): BrowserDatabaseStatus;
}

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

/**
 * The oracle's entry point, and not a product API.
 *
 * `apps/theoremweb/oracles/pwa-opfs-ledger.mjs` drives this from a worker to
 * prove the claim section 32 makes: a log opened here survives a reload with
 * no server, appends replay idempotently by digest, and a foreign deployment
 * is refused. The product-facing browser API above the log is
 * `fold-reader-wasm`'s task; this exists so the storage backend has a real
 * browser oracle before that API is designed.
 *
 * One call = open the log (creating it when absent), append one deterministic
 * record for `payload`, re-read the whole file from OPFS, verify the chain,
 * and report what was found.
 */
export function opfs_ledger_probe(directory: string, deployment_id: string, payload: string): Promise<string>;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_browserdatabase_free: (a: number, b: number) => void;
    readonly browserdatabase_command: (a: number, b: number, c: number) => void;
    readonly browserdatabase_compact: (a: number) => number;
    readonly browserdatabase_explain: (a: number, b: number, c: number, d: number) => void;
    readonly browserdatabase_exportSnapshot: (a: number, b: number) => void;
    readonly browserdatabase_importSnapshot: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly browserdatabase_inMemory: (a: number, b: number, c: number) => void;
    readonly browserdatabase_open: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly browserdatabase_query: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly browserdatabase_queryAt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly browserdatabase_queryEvidence: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly browserdatabase_queryValidAt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly browserdatabase_recordCall: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly browserdatabase_setCsvSources: (a: number, b: number, c: number) => void;
    readonly browserdatabase_status: (a: number, b: number) => void;
    readonly rust_zstd_wasm_shim_calloc: (a: number, b: number) => number;
    readonly rust_zstd_wasm_shim_free: (a: number) => void;
    readonly rust_zstd_wasm_shim_malloc: (a: number) => number;
    readonly rust_zstd_wasm_shim_memcmp: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_memcpy: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_memmove: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_memset: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_qsort: (a: number, b: number, c: number, d: number) => void;
    readonly ring_core_0_17_14__bn_mul_mont: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly __wbg_intounderlyingbytesource_free: (a: number, b: number) => void;
    readonly __wbg_intounderlyingsink_free: (a: number, b: number) => void;
    readonly __wbg_intounderlyingsource_free: (a: number, b: number) => void;
    readonly intounderlyingbytesource_autoAllocateChunkSize: (a: number) => number;
    readonly intounderlyingbytesource_cancel: (a: number) => void;
    readonly intounderlyingbytesource_pull: (a: number, b: number) => number;
    readonly intounderlyingbytesource_start: (a: number, b: number) => void;
    readonly intounderlyingbytesource_type: (a: number) => number;
    readonly intounderlyingsink_abort: (a: number, b: number) => number;
    readonly intounderlyingsink_close: (a: number) => number;
    readonly intounderlyingsink_write: (a: number, b: number) => number;
    readonly intounderlyingsource_cancel: (a: number) => void;
    readonly intounderlyingsource_pull: (a: number, b: number) => number;
    readonly opfs_ledger_probe: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly __wasm_bindgen_func_elem_17437: (a: number, b: number, c: number, d: number) => void;
    readonly __wasm_bindgen_func_elem_17460: (a: number, b: number, c: number, d: number) => void;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export3: (a: number) => void;
    readonly __wbindgen_export4: (a: number, b: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export5: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
