/**
 * A failed call. `code` is stable for programs: for example
 * `cypher_write_unsupported` (a write handed to `query`), `owner_record` (a
 * mutation touching a record another owner keeps), `ownership_refused` (the
 * file is held by another worker), `read_only`, `invalid_arguments`,
 * `invalid_options`, `database_closed` and `worker_failure` (the worker
 * stopped; every later call fails the same way, so open the database again).
 */
export declare class RustyRedError extends Error {
  readonly code: string
}

export interface Node {
  id: string
  labels: Array<string>
  properties: Record<string, unknown>
}

export interface Edge {
  id: string
  from: string
  to: string
  type: string
  properties: Record<string, unknown>
}

/**
 * One atomic commit. Deletes apply before upserts, whatever the order of the
 * lists. Deleting a node also deletes its edges, except those this batch
 * upserts. An upsert replaces the whole record, and an edge's ends must exist
 * once the batch's node upserts are applied.
 */
export interface Batch {
  deleteEdges?: Array<string>
  deleteNodes?: Array<string>
  upsertNodes?: Array<Node>
  upsertEdges?: Array<Edge>
}

export interface Commit {
  txnId: number
  graphVersion: number
}

/** Which nodes `queryNodes` returns. Every given condition must hold. */
export interface NodeFilter {
  label?: string
  /** Properties each node must equal. Strings, numbers, booleans and null are indexed. */
  properties?: Record<string, unknown>
  /** A string property each node's value must start with. The nodes then come in byte order of that value. */
  prefix?: { property: string; value: string }
  limit?: number
}

export interface NeighborFilter {
  nodeId: string
  direction: 'out' | 'in'
  edgeType?: string
}

/** A node next to the one asked about, and the edge between them. */
export interface Neighbor {
  edgeId: string
  nodeId: string
  type: string
  properties: Record<string, unknown>
}

export interface QueryResult {
  columns: Array<string>
  rows: Array<Array<unknown>>
  truncated: boolean
}

export interface Inspection {
  writable: boolean
  version: number
  nodes: number
  edges: number
  /** The past versions the file holds, the current one included; null when it records none. */
  history: { commits: number; oldestMs: number } | null
  /** The window this handle was opened with, or null when it keeps every version. */
  historyDays: number | null
}

export interface Compaction {
  generation: number
  chunksRemoved: number
  bytesRemoved: number
  /** Past versions cut because they were older than `historyDays`. */
  commitsRemoved: number
}

/** A read a subscription keeps current. */
export type Read =
  | { method: 'inspect' }
  | { method: 'getNode' | 'getEdge'; args: { id: string } }
  | { method: 'queryNodes'; args?: NodeFilter }
  | { method: 'neighbors'; args: NeighborFilter }
  | { method: 'query'; args: { cypher: string; params?: Record<string, unknown>; rowCap?: number } }

/**
 * How the graph is opened. Unknown options are refused with `invalid_options`.
 *
 * Every commit is durable before its promise resolves. Past versions of
 * records stay in the file as the graph's history, for as long as
 * `historyDays` says.
 */
export interface OpenOptions {
  /** A write to a labelled node also commits a `ControlEvent` node recording it. Defaults to true. */
  controlEvents?: boolean
  /**
   * Days of past versions to keep; fractions allowed. The current state is
   * always kept. Older versions are cut, and their bytes reclaimed, when the
   * database is compacted. Absent keeps every version. It applies to this
   * handle: the file does not remember it.
   */
  historyDays?: number
  /**
   * A string `ownership` property marks a record as a subsystem's, so
   * `mutate` refuses to write the key or change such a record. Defaults to
   * true. Set it false for a database no subsystem writes to, such as an
   * application's own, where `ownership` is an ordinary property.
   */
  ownershipMarkers?: boolean
}

export interface CompactOptions {
  /**
   * Days of past versions to keep in this compaction, in place of the
   * handle's `historyDays`. Useful when several pages share one database
   * and the one compacting knows the window.
   */
  historyDays?: number
}

export interface WorkerSettings {
  /**
   * A worker running `@rustyreddb/browser/worker`, or a function that makes
   * one, for a bundler that needs to make it itself. A shared database makes
   * its worker only when this page comes to hold the file, so give it the function.
   */
  worker?: Worker | (() => Worker)
  /** Where the wasm module is, when it is not beside the package's own glue. */
  wasm?: string | URL
}

export declare class Database {
  private constructor()
  inspect(): Promise<Inspection>
  /**
   * Commit one batch. It is refused with `owner_record`, and nothing commits,
   * when it changes what another owner keeps, by the rules a Cypher write
   * follows: control events, schema, Files ledgers and the like (by label,
   * type or reserved ID), edges owned for what they connect (such as AgentFS
   * `CHILD` edges), the provenance overlay's label and fields, `_rr_` and
   * `ownership` keys (the latter unless opened with `ownershipMarkers: false`),
   * and edges a node delete would take with it.
   */
  mutate(batch: Batch): Promise<Commit>
  getNode(id: string): Promise<Node | null>
  getEdge(id: string): Promise<Edge | null>
  queryNodes(filter?: NodeFilter): Promise<Array<Node>>
  neighbors(filter: NeighborFilter): Promise<Array<Neighbor>>
  /** Run one read-only Cypher query with bound parameters. `rowCap` defaults to 1000. */
  query(cypher: string, params?: Record<string, unknown>, rowCap?: number): Promise<QueryResult>
  /**
   * Rewrite the file without what nothing reaches any more, after cutting the
   * versions older than `options.historyDays`, or the handle's `historyDays`
   * when that is absent. It copies everything kept, so it costs about as much
   * as the file is large. Refused with `in_memory` for an in-memory database
   * and `read_only` for a read-only one.
   */
  compact(options?: CompactOptions): Promise<Compaction>
  /**
   * Keep a read current. `next` receives its result now and again after any
   * commit that changes it. Returns the function that stops it.
   */
  subscribe(read: Read, next: (value: any) => void, error?: (error: RustyRedError) => void): () => void
  /** Whether this page holds the database's file. Always true unless it was opened shared. */
  readonly owner: boolean
  /**
   * Release the database and stop its worker. Later calls reject with
   * `database_closed`. A shared database stays open for the other pages.
   */
  close(): Promise<void>
}

export interface SharedSettings {
  /**
   * Use one database with every page of the origin that opens this name the
   * same way. One page holds the file and the others reach it through that
   * page; another takes over when it closes or its tab goes. A call the last
   * holder committed but did not answer is made again by the next.
   */
  shared?: boolean
}

/**
 * Open, creating when absent, the database named `name` in this origin's
 * private file system. Without `shared`, one page holds a database at a time
 * and a second `open` is refused.
 */
export declare function open(
  name: string,
  settings?: OpenOptions & WorkerSettings & SharedSettings,
): Promise<Database>

/** An empty graph with no file and no durability. */
export declare function inMemory(settings?: OpenOptions & WorkerSettings): Promise<Database>

/** Delete the database named `name`. It must not be open. */
export declare function remove(name: string): Promise<void>
