// The dedicated worker that owns one database.
//
// OPFS synchronous access handles exist only in a dedicated worker, and an
// open handle is an exclusive lock on its file, so one worker holds one
// database. Every write goes through this worker, which is why a subscription
// can be kept current by running its read again after each commit.
import init, { BrowserDatabase } from '../pkg/rustyred_thg_browser.js'

// The file a database named `name` keeps in its OPFS directory.
const FILE = 'database.RR'
const READS = new Set(['inspect', 'getNode', 'getEdge', 'queryNodes', 'neighbors', 'query'])
const WRITES = new Set(['mutate'])

let database = null
const subscriptions = new Map()

const failure = (error) => ({
  code: typeof error?.code === 'string' ? error.code : 'worker_failure',
  message: error?.message ?? String(error),
})

const refusal = (code, message) => Object.assign(new Error(message), { code })

// Record calls take and return JSON text, so an unchanged read is the same string.
const call = (method, args) => database.recordCall(method, JSON.stringify(args ?? null))

function publish(id) {
  const subscription = subscriptions.get(id)
  let text
  try {
    text = call(subscription.method, subscription.args)
  } catch (error) {
    subscription.last = undefined
    postMessage({ subscription: id, error: failure(error) })
    return
  }
  if (text === subscription.last) return
  subscription.last = text
  postMessage({ subscription: id, value: JSON.parse(text) })
}

// Without a location the glue fetches the module from beside itself.
const load = (wasm) => (wasm === undefined ? init() : init({ module_or_path: wasm }))

async function openNamed(name, options) {
  if (
    !self.isSecureContext ||
    typeof navigator.storage?.getDirectory !== 'function' ||
    typeof self.FileSystemFileHandle?.prototype.createSyncAccessHandle !== 'function'
  ) {
    throw refusal('opfs_unavailable', 'this worker cannot hold files in the origin private file system')
  }
  try {
    return await BrowserDatabase.open(name, FILE, 'open', options)
  } catch (error) {
    if (error?.code !== 'database_missing') throw error
    return BrowserDatabase.open(name, FILE, 'create', options)
  }
}

async function handle(message) {
  switch (message.op) {
    case 'open':
      if (database) throw refusal('database_already_open', 'this worker already holds a database')
      await load(message.wasm)
      database = await openNamed(message.name, JSON.stringify(message.options ?? {}))
      return null
    case 'inMemory':
      if (database) throw refusal('database_already_open', 'this worker already holds a database')
      await load(message.wasm)
      database = BrowserDatabase.inMemory(JSON.stringify(message.options ?? {}))
      return null
    case 'call': {
      if (message.method === 'close') {
        database?.free()
        database = null
        subscriptions.clear()
        return null
      }
      if (!database) throw refusal('database_closed', 'the database is closed')
      if (message.method === 'compact') {
        // Rewrites the file, cutting the versions older than the window given
        // here, or the handle's when none is.
        // The cut is committed before the rewrite, so a compaction that fails
        // may still have changed history: refresh subscriptions either way,
        // unless the module trapped and nothing more can run in it.
        let report
        try {
          report = await database.compact(message.args?.historyDays ?? undefined)
        } catch (error) {
          if (!(error instanceof WebAssembly.RuntimeError)) {
            for (const id of subscriptions.keys()) publish(id)
          }
          throw error
        }
        for (const id of subscriptions.keys()) publish(id)
        return Object.fromEntries(Object.entries(report).map(([key, n]) => [key, Number(n)]))
      }
      const value = JSON.parse(call(message.method, message.args))
      if (WRITES.has(message.method)) for (const id of subscriptions.keys()) publish(id)
      return value
    }
    case 'subscribe':
      if (!database) throw refusal('database_closed', 'the database is closed')
      if (!READS.has(message.method)) {
        throw refusal('invalid_subscription', `${message.method} is not a read`)
      }
      subscriptions.set(message.subscription, {
        method: message.method,
        args: message.args ?? null,
        last: undefined,
      })
      publish(message.subscription)
      return null
    case 'unsubscribe':
      subscriptions.delete(message.subscription)
      return null
    default:
      throw refusal('unknown_method', `unknown operation ${message.op}`)
  }
}

// Messages are answered in the order they arrive: `open` is asynchronous and
// nothing may reach the database before it settles.
let queue = Promise.resolve()
addEventListener('message', ({ data }) => {
  queue = queue.then(async () => {
    try {
      postMessage({ id: data.id, ok: true, value: await handle(data) })
    } catch (error) {
      postMessage({ id: data.id, ok: false, error: failure(error) })
      // A trap (a Rust panic) leaves the module's memory as it was mid-call,
      // so nothing more can run here. The client fails every later call.
      if (error instanceof WebAssembly.RuntimeError) {
        database = null
        subscriptions.clear()
        postMessage({ stopped: failure(error) })
        close()
      }
    }
  })
})
