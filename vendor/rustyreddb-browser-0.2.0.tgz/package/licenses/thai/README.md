These are source-pinned resources for the existing Relate fulltext analyzer.
The two unmodified break data files and dictionary are the original resources
from the Temurin JRE 25.0.4.1+1 modular image. They are kept in this directory
as a distinct data package. Relate uses its independent Rust table reader.
Native and WASM builds include the same resources.

- [Pinned Temurin JRE download](https://github.com/adoptium/temurin25-binaries/releases/download/jdk-25.0.4.1%2B1/OpenJDK25U-jre_aarch64_mac_hotspot_25.0.4.1_1.tar.gz).
  Archive SHA-256: `5b02bcc908da092e7e00b9772d4f9bbb87f44a60b7c90f7cf5a91a1d98f37e1b`.
- [Corresponding OpenJDK source at commit 7b65d74](https://github.com/adoptium/jdk25u/tree/7b65d74bcbd7c3a0b4c1f5c5bd85e64aa2e51b4a).
  Original word and sentence rules are alongside this notice. The upstream
  source also includes the generator in `make/jdk/src/classes/build/tools/generatebreakiteratordata`,
  the build rule in `make/modules/java.base/gendata/GendataBreakIterator.gmk`, and Unicode
  inputs under `src/java.base/share/data/unicodedata`. See [OpenJDK license and Classpath exception](LICENSE-OPENJDK).
- `thai_dict` is distributed under its separate [Thai Dictionary license](LICENSE-THAI-DICTIONARY.md).
- `thai-stop.txt` contains the active entries of Apache Lucene 10.5.1
  [Thai analyzer's stopword list](https://github.com/apache/lucene/blob/releases/lucene/10.5.1/lucene/analysis/common/src/resources/org/apache/lucene/analysis/th/stopwords.txt).
  See the [Apache license](../../../../../LICENSE).
- `java25-*.bin` record Unicode letter and decimal membership for JDK 25.
  Generate them with `javac ThaiCharacterTables.java` and
  `java ThaiCharacterTables .` on the pinned JDK.

Use JDK 25's `jimage extract --include '**/WordBreakIteratorData_th,**/SentenceBreakIteratorData,**/thai_dict' --dir extracted path/to/lib/modules` on the pinned
archive. Copy the three extracted files without transformation and compare
`SHA256SUMS`. An actual Lucene 10.5.1 ThaiAnalyzer corpus checks terms and
positions. ICU4X specifies different dictionary boundaries, including several
common Thai phrases, so it produces a different query/index vocabulary.
