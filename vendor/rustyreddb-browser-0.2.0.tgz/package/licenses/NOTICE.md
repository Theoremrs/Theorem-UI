# Third-party attribution

## Rust text model behavioral oracle

The operation, tracked-interval, and grouped-undo behavior in
`rustyred-thg-text-model` was independently implemented after studying:

- Project: JetBrains IntelliJ Community
- Upstream module: `fleet/andel`
- Revision: `f321ea22aa381223a3a9f8bad564eaad244c040b`
- Upstream source license: Apache-2.0
- Upstream header: `Copyright 2000-2025 JetBrains s.r.o. and contributors.
  Use of this source code is governed by the Apache 2.0 license.`

No upstream Java or Kotlin source, binary artifact, serialization format, or
public API is included. Rope storage is provided by the independent `ropey`
crate rather than by the upstream module.

## Editor.js block-schema contract donor

`packaging/theorem-block-registry` ports Editor.js contracts only: the flat
`{id, type, data}` block schema, `conversionConfig`, toolbox entries, and
per-type sanitize rules. No Editor.js JavaScript runtime, renderer, or
editor UI is included.

- Project: Editor.js
- Upstream license: Apache-2.0
- Ported surface: schema and configuration contracts, re-expressed as Rust
  types in `theorem-block-registry`


## Relate query crates (Cypher frontend and executor)

`rustyred-thg-cypher` and `rustyred-thg-cypher-engine` use crates from
https://github.com/relatedb/relate. The frontend, executor, planner and engine API have
vendored pins under `rustyredcore_THG/vendor/relate-*`, each with the
upstream license and a record of its changes; other crates use the Git pin.

- Project: Relate (relatedb)
- Revision: `a067fca55f563b1fa641e5d01f6f31d7e7b10782`
- Upstream license: Apache-2.0 (LICENSE at the repository root; no upstream
  NOTICE file exists at this revision)
- Used directly: `relate-parser`, `relate-front`, `relate-ir`,
  `relate-planner` (frontend); `relate-executor`, `relate-engine-api`,
  `relate-core`, `relate-ir` (executor)
- Used transitively: other crates from the same repository

The upstream repository carries a "Neo4j Labs Disclaimer": the project is
experimental, provided as is, and not approved for production use by its
publisher. It is recorded so the dependency decision is made with it in view.
Neo4j and Cypher are trademarks of Neo4j, Inc.; these crates implement a
compatibility target and are not affiliated with or endorsed by Neo4j.

## Portable fulltext analyzer data and kernels

The Relate executor fork uses [Apache Lucene 10.5.1](https://github.com/apache/lucene/tree/releases/lucene/10.5.1)
analyzer resources, including generated tokenizer tables, and
[Snowball 2.2.0](https://github.com/snowballstem/snowball/tree/48a67a2831005f49c48ec29a5837640e23e54e6b)
language stemmers generated for Rust. The
[fulltext provenance record](rustyredcore_THG/vendor/relate-executor/src/exec/fulltext/locale/PROVENANCE.md)
links to the Apache-2.0 and BSD notices, exact versions and table regeneration
instructions. No Neo4j or JVM runtime is used by these analyzers.


The Relate fulltext Thai analyzer embeds two original Temurin/OpenJDK 25.0.4.1+1
generated break tables and the original Royal Institute/NECTEC dictionary.
The table sources use GPL-2.0-only with the Classpath exception. The dictionary
has a separate permissive license. Source links, license notices and
reproducible hashes are in
[rustyredcore_THG/vendor/relate-executor/src/exec/fulltext/thai/data](rustyredcore_THG/vendor/relate-executor/src/exec/fulltext/thai/data/README.md).
The Rust adapter uses the portable RE# (resharp, MIT) fork and to-regex-range
(MIT or Apache-2.0) for fulltext regular expression evaluation. See the
[RE# source pin and notice](rustyredcore_THG/vendor/resharp-portable/PIN.md).
