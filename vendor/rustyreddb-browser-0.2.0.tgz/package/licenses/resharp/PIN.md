# RE# scalar portability patch

The source is the engine from [RE# 0.7.7 at db162a8](https://github.com/ieviev/resharp/tree/db162a8950071205e794930555b9ffeb79e28923/resharp-engine).
The registry archive SHA-256 is
`b04101c08a724d96e8085ebf804d3e4799a6b9165334a43e5a12583d09666446`.
The [MIT license](LICENSE) applies to the original and modified engine.

The published package requires SIMD even though its regex automata already
have a scalar path. This patch supplies scalar prefix and skip helpers and
lets the existing runtime detection choose the automaton's scalar path on
targets without SSE/NEON or WASM SIMD128. The matching engine and the regex
grammar are unchanged. Literal helpers use memchr's portable
implementations. Optional SIMD backends remain available as upstream.
The manifest keeps the original library and feature options and omits
upstream benchmark, example and development-only targets that this host
does not package. The algebra and parser crates remain pinned on crates.io.
